create function drop_db(username character varying, password character varying, dbname text, db_user character varying) returns void
    language plpgsql
as
$$
BEGIN
	PERFORM dblink_exec(format('user=postgres password=123 dbname=calories_app'),
							'DROP DATABASE IF EXISTS ' || quote_ident(dbname));
   	PERFORM dblink_exec(format('user=postgres password=123 dbname=calories_app'),
							format('DROP USER IF EXISTS %I', db_user));
END;
$$;

alter function drop_db(varchar, varchar, text, varchar) owner to postgres;

